public class GUIReportGenerator extends javax.swing.JFrame {
  double amountEarned;
  double NumOfMinutes;
  final int sessions = 4;
  int i, j;
  
  double [][] tutoring = new double[sessions][2]; 
  
  /**
   * CREATES new form GUIReportGenerator
   */
  public GUIReportGenerator() {
    
  }
  
  private void jAmountTextFieldActionPerformed(java.awt.event.ActionEvent evt) {
    // TODO add your handling code here:
  }
  
  private void enterActionPerformed(java.awt.event.ActionEvent evt) {
    //allocating the text Fields to the variables.
    double time = Double.parseDouble(jTimeTextField.getText());
    double amount = Double.parseDouble(jAmountTextField.getText());
    
    for ( i =0; i <tutoring.length ;i++)
    {
      NumOfMinutes = time;
      tutoring[i][0] = NumOfMinutes;
      amountEarned = amount;
      tutoring[i][1] = amountEarned;
      jTextArea1.setText(" ");
      for (int j= 0; j<sessions ; j++)
      {
        jTextArea1.setText(tutoring[i][0]+ "   " + tutoring[i][1]  );
        
      }
      jTextArea1.append("\n");
    }
    
  }