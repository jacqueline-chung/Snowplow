/*
 * GUI display part of the snow plow program
 * [SnowplowGUIDisplay.java]
 * Author: Duffy Du
 * Oct 21, 2015
 */

import javax.swing.*;
import java.awt.*;
import java.util.Random;//import randoM
import java.awt.event.*;

public class SnowplowGUIDisplay extends JFrame implements ActionListener{
  Random random = new Random();//create a random number generator called random
  int[][] arr = new int[8][8];//create the 2d array that stores all the numbers
  
  //GUI components
  JLabel[][] grid = new JLabel[8][8];//create 8x8 labels
  JButton plowButton = new JButton("PLOW THE SNOW");
  JButton resetButton = new JButton("Reset");
  
  //panels
  //create 8 panels for the rows
  JPanel[] pan = new JPanel[8];
  
  FlowLayout flow = new FlowLayout();
  
  boolean firstOneFound=false;//a boolean that checks if the first one is found or not
  int r1=0,c1=0;//variables that stores the position of the first one in the grid
  
  //**********constructor**************
  public SnowplowGUIDisplay(){
    setTitle("Snow plow GUI Display");
    setSize(240,360);
    setLayout(flow);
    
    for (int i =0;i<8;i++){
      pan[i] = new JPanel();
      pan[i].setLayout(flow);
      for (int j=0;j<8;j++){
        //generate random numbers between 1 and 2 and stores it in the array
        arr[i][j] = random.nextInt(2)+1;
        //store the position of the first one in to r1 and c1
        if (!firstOneFound && i==0 && arr[i][j] == 1){
          r1 = i;
          c1 = j;
          firstOneFound = true;
        }
        
        grid[i][j] = new JLabel(Integer.toString(arr[i][j])+ " ");
        //use colors to distinguish 1s and 2s
        if (arr[i][j]==1){
          grid[i][j].setForeground(Color.RED);
        } else if (arr[i][j]==2){
          grid[i][j].setForeground(Color.BLUE);
        }
        pan[i].add(grid[i][j]);
        add(pan[i]);
      }
    }
    
    add(plowButton);
    plowButton.addActionListener(this);
    add(resetButton);
    resetButton.addActionListener(this);
    setVisible(true);
  }
  
  //**********event performed method************
  public void actionPerformed(ActionEvent event){
    String command = event.getActionCommand();
    
    if (command.equals("PLOW THE SNOW")){
      System.out.println("plowing snow...");
      
      //find the first 1 value in the first row
      if (firstOneFound){
        System.out.println("position of the first 1 value = " + "(" + r1 + "," + c1 + ").");
      } else {
        //when there is no 1 found in the first row
        System.out.println("the plow is not used"); 
      }
      
      //clear
      clear(arr,r1,c1);
      
      //display in GUI
      for (int i =0;i<8;i++){
        for (int j=0;j<8;j++){
          grid[i][j].setText(Integer.toString(arr[i][j])+ " ");
          if((grid[i][j].getText()).equals("0 ")){
            grid[i][j].setForeground(Color.GREEN);
          }
        }
      }
      
    } else if (command.equals("Reset")){
      //reset variables
      firstOneFound = false;
      
      for (int i =0;i<8;i++){
        for (int j=0;j<8;j++){
          //generate random numbers between 1 and 2 and stores it in the array
          arr[i][j] = random.nextInt(2)+1;
          //store the position of the first one in to r1 and c1
          if (!firstOneFound && i==0 && arr[i][j] == 1){
            r1 = i;
            c1 = j;
            firstOneFound = true;
          }
          
          grid[i][j].setText(Integer.toString(arr[i][j])+ " ");
          //use colors to distinguish 1s and 2s
          if (arr[i][j]==1){
            grid[i][j].setForeground(Color.RED);
          } else if (arr[i][j]==2){
            grid[i][j].setForeground(Color.BLUE);
          }   
        }
      }
    } 
  }
  
  //**************display method********************
  public static void display(int[][] arr){
    System.out.println();
    for (int i=0;i<8;i++){
      for (int j=0;j<8;j++){
        System.out.print(arr[i][j] + " ");
      }
      System.out.println();
    }
  }
  
  //**************clear method****************
  public static void clear(int[][] arr,int r, int c){
    boolean allClear = true;
    int[] r1 = new int[8];
    int[] c1 = new int[8];
    int counter = 0;
    arr[r][c] = 0;
    int a=1,b=1, d=1, e=1;
    
    if(r==0){
      a--;
    }else if(r==7){
      b--;
    }
    
    if(c==0){
      d--;
    }else if(c==7){
      e--;
    }
    
    //for loops that check 9 gong ge around the one
    for (int i=r-a; i<=r+b;i++){
      for (int j=c-d; j<=c+e;j++){
                
        if (arr[i][j]==1){
          
          arr[i][j]=0;
          //System.out.println("element at " + "(" + i + "," + j + ") is set to 0.");
          r1[counter] = i;
          c1[counter] = j;
          counter++;
          //display(arr);
          
          allClear = false;
        } 
      }
    }
    
    for (int i=0;i<counter;i++){
      if (!allClear){
        clear(arr,r1[i],c1[i]);
      }
    }   
  }
  
  public static void main (String args[]){
    SnowplowGUIDisplay frame = new SnowplowGUIDisplay();
  }
  
}