/* Name of Program: [SnowPlowV2.java]
 * Author: Jacqueline Chung
 * Date: October 19-27, 2015
 * Teacher: Ms. Angrighetti 
 * Description: My program will output  8x8 array of 1s and 2s (in different colours). There will be two buttons to called "Reset" and "Plow" for the user
 * to choose to Reset the numbers or remove the unblocked 1s. It will count the number of times the Reset button is pressed.
 * When plowed it will change the unblocked 1s into 0s, which are another colour. It will give a popup message (dialog box)
 * of where the first 1 was first on the first row of the array/grid.
 * My Algorithm changed!! Please see new Algorithm I submitted with the GUI.
 */

//SHOULD I USE VOID
//WHY IS IT PRNTING DIFFERENT
//EFFICIENCY????
//CLEAR METHOD RIGHT POSITION??



// These imports are required to use GUI components
import javax.swing.*;
import java.awt.*; 
import java.awt.event.*;
import java.util.Random; //required for Random generator

public class SnowPlowV2 extends JFrame implements ActionListener { //Jframe and Actionlistener needed for buttons and frame
  // class variables
  
  //declare counter for reset
  int countReset = 0;
  
  //panels 
  JPanel pan1 = new JPanel(); //for 2d array
  JPanel pan2 = new JPanel(); //for buttons
  
  //add grid
  static JLabel[][] gridLabel = new JLabel[8][8];//declare 8x8 labels as a global variable
  //add labels for counter
  JLabel titleLabel = new JLabel("SNOW PLOWING"); //title
  JLabel countLabel = new JLabel("Pressed Reset: " + countReset); //counter for reset button
  
  // buttons used to change the colour of the label text
  JButton resetButton = new JButton("Reset");
  JButton plowButton = new JButton("Plow"); 
  
  //add fonts
  Font font1 = new Font("Serif", Font.BOLD, 16); //font for title
  //Font font2 = new Font("Serif", Font.BOLD, 11); //font for everything else
  
  //dialog box to give messages
  static int mc = JOptionPane.WARNING_MESSAGE; //declare option pane as a global variable
  
  //declare variables to check in console and prevent repetition
  Random rand = new Random();
  boolean firstFound = false;
  int[][] array = new int[8][8];
  int r1 = 0, c1 = 0;
  
  public SnowPlowV2() {  //a special method called a constructor. It must have the same name as your class. This is where all your 
    //code goes to set up the frame
    setTitle("SNOWPLOW"); //set a title for GUI
    setSize(270, 320); //set size
    setResizable(false); // prevents user from changing the size 
    
    // set layout using GridLayout
    setLayout(new GridLayout());
    pan2.setLayout(new GridLayout(2, 1));
    
    //add panels
    add(pan1);
    add(pan2);
    
    //set font and colours for the title and date
    titleLabel.setFont(font1);
    titleLabel.setForeground(Color.RED);
    //set background colour
    pan1.setBackground(Color.white);
    
    //add pan1 components
    pan1.add(titleLabel);
    
    for (int row = 0; row < array.length; row++) {
      for (int col = 0; col < array[row].length; col++) {   
        //array[row][col] = rand.nextInt(2)+1;
        System.out.print((array[row][col] = rand.nextInt(2) + 1) + " "); //test on console
        gridLabel[row][col] = new JLabel(Integer.toString(array[row][col] = rand.nextInt(2) + 1) + " "); //convert into String
        //gridLabel[row][col] = new JLabel(Integer.toString(array[row][col]) + " "); //convert into String
        //System.out.print(array[row][col] + " "); //test on console
        
        //use colors to distinguish 1s and 2s
        if (array[row][col] == 1) { //if 1 set colour to green
          gridLabel[row][col].setForeground(Color.GREEN);
        } else if (array[row][col] == 2) { //if 2 set colour to black
          gridLabel[row][col].setForeground(Color.BLACK);
        }
        pan1.add(gridLabel[row][col]); //add grid to pan1
        
        if (!firstFound && row == 0 && array[row][col] == 1){ //if 1 was found on the first row
          r1 = row; //set row where it was first found
          c1 = col; //set column where it was first found
          firstFound = true; //set firstFound to true (it was found on the first row)
        }
      }
      System.out.println();
    }
    
    pan1.add(countLabel); //add count label
    
    //pan2 components
    //add button that resets 1's and 2's
    resetButton.addActionListener(this);
    pan2.add(resetButton);
    
    //add button to 'plow' snow (1's) 
    plowButton.addActionListener(this);
    pan2.add(plowButton);
    
    setVisible(true); 
  }
  
  /* This method will perform the action retrieved from the event listener.
   * This will change colour of 0, 1 and 2 */
  public void actionPerformed(ActionEvent event) {
    String command = event.getActionCommand(); //declare command variable
    
    if (command.equals("Reset")) { //if user presses Reset button
      System.out.print("Reset button pressed\n"); //test for listener
      
      plowButton.setEnabled(true); //enable plow button
      
      firstFound = false; //set firstFound false again
      
      //to count the number of times the Reset button is pressed
      countReset++; //add one each time
      countLabel.setText("Pressed Reset: " + countReset); //output new count
      
      for (int row = 0; row < array.length; row++) {
        for (int col = 0; col < array[row].length; col++) {
          // if (r1 >= 0 && r1 <= 7 || c1 >= 0 && c1 <= 7) { //if NOT out of bounds
          System.out.print((array[row][col] = rand.nextInt(2) + 1) + " "); //test on console
          gridLabel[row][col].setText((array[row][col] = rand.nextInt(2) + 1) + " "); //set text to new set of 1s and 2s
          
          if (!firstFound && row == 0 && array[row][col] == 1) { //if 1 was found on the first row
            r1 = row; //set row where it was first found
            c1 = col; //set column where it was first found
            firstFound = true; //set firstFound to true (it was found on first row)
          }
          
          //use different colours to separate colours of 1 and 2
          if (array[row][col] == 1) { //if 1 make it green
            gridLabel[row][col].setForeground(Color.GREEN);
          } else if (array[row][col] == 2) { //if 2 make it black
            gridLabel[row][col].setForeground(Color.BLACK);
          }
          //}        
        }
        System.out.println();
      }
      
    } else if (command.equals("Plow")) { //if user presses 'Plow' button
      System.out.println("Plow Button pressed"); //test in console      
      
      plowButton.setEnabled(false); //disable button so it's only pressed once
      
      if (firstFound){
        System.out.println("Snow first found on" + "(" + (r1 + 1) + "," + (c1 + 1) + ")."); //test on console
        JOptionPane.showMessageDialog (null, "Snow first found on " + "(" + (r1 + 1) + "," + (c1 + 1) + ").", "Message", mc); //show message of where it was first found with coordinates
        
      } else { //when there is no 1 found in the first row
        System.out.println("Nothing plowed"); //test on console
        JOptionPane.showMessageDialog (null, "Nothing plowed.", "Message", mc); //show message when nothing is plowed
      }
      
      //if (r1 >= 0 && r1 <= 7 || c1 >= 0 && c1 <= 7) { //if NOT out of bounds
      clear(array,r1, c1); //call clear method to plow snow
      //}
      
      //display in GUI
      for (int i = 0;i < 8; i++){
        for (int j = 0; j < 8; j++){
          gridLabel[i][j].setText(Integer.toString(array[i][j])+ " ");
          if((gridLabel[i][j].getText()).equals("0 ")){
            gridLabel[i][j].setForeground(Color.BLUE);
          }
        }
      }
    }
  }
  
  ///////////////clear (plow) method/////////////////////
  public static void clear (int[][] grid, int r, int c) { //this plows or clears the unblocked snow (1's)
    int rFirst = 1, rLast = 1, cFirst = 1, cLast = 1; //declare variables to check if position is out of bounds
    if (grid[r][c] == 1) { //if 1 was found on the first row  
      grid[r][c] = 0; //set the first position to zero
    
    //the situations row or column is out of bounds 
    if (r == 0) {  
      rFirst--;
    } else if (r == 7) {
      rLast--;
    }
    
    if (c == 0) {
      cFirst--;
    } else if (c == 7) {
      cLast--;
    }
    
    if (r >= 0 && r <= 7 && c >= 0 && c <= 7) { //if NOT out of bounds
      System.out.print(grid[r][c] + " "); //test on console
      gridLabel[r][c].setText(Integer.toString(grid[r][c])+ " "); //convert numbers to strings
      
      if((gridLabel[r][c].getText()).equals("0 ")){ //if the number equals to zero, make it blue colour
        //delay (1000);
        clear (grid, r + rLast, c);
        clear (grid, r + rLast, c + cLast);
        clear (grid, r + rLast, c - cFirst);
        clear (grid, r - rFirst, c);
        clear (grid, r - rFirst, c - cFirst);
        clear (grid, r - rFirst, c + cLast);
        clear (grid, r, c + cLast);
        clear (grid, r, c - cFirst);

//gridLabel[r][c].setForeground(Color.BLUE); //display grid or snow plowed in blue
        
        //call clear method to check for 1s around it (up, down, and diagionally)
//        clear (grid, r + 1, c);
//        clear (grid, r + 1, c + 1);
//        clear (grid, r + 1, c - 1);
//        clear (grid, r - 1, c);
//        clear (grid, r - 1, c - 1);
//        clear (grid, r - 1, c + 1);
//        clear (grid, r, c + 1);
//        clear (grid, r, c - 1);
      }
    }
    }
    

//    
//    for (int row = r - rFirst; row < r + rLast; row++) {
//      for (int col = c - cFirst; col < c + cLast; col++) {
    
    ////CORRECT ARRAY LENGTH AND INTIALIZATION
    
//    for (int row = 0; row < r; row++) {
//      for (int col = 0; col < c; col++) {
//        if (r >= 0 && r <= 7 || c >= 0 && c <= 7) { //if NOT out of bounds
//          System.out.print(grid[row][col] + " "); //test on console
//          gridLabel[row][col].setText(Integer.toString(grid[row][col])+ " "); //convert numbers to strings
//          
////          if (grid[row][col] == 1){
////            grid[row][col] = 0;
////          }
//          
//          if((gridLabel[row][col].getText()).equals("1 ")){ //if the number equals to zero, make it blue colour
//            //gridLabel[row][col].setForeground(Color.BLUE); //display grid or snow plowed in blue
//            
//            //call clear method to check for 1s around it (up, down, and diagionally)
//            clear (grid, r + 1, c);
//            clear (grid, r + 1, c + 1);
//            clear (grid, r + 1, c - 1);
//            clear (grid, r - 1, c);
//            clear (grid, r - 1, c - 1);
//            clear (grid, r - 1, c + 1);
//            clear (grid, r, c + 1);
//            clear (grid, r, c - 1);
//          }
//        }
//      }
//      System.out.println(); 
//    }
  }
  
  public static void main(String args[]) throws Exception {  //main method
    SnowPlowV2 frame = new SnowPlowV2(); //one line of code to create the frame  
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //when closed it resets interactions
  } //end main method
}