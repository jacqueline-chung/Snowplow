import java.text.DecimalFormat; // program uses class DecimalFormat
import javax.swing.*; 

import java.awt.*;


public class Inventory_GUI
{
  static JFrame frame1;
  static Container pane;
  static JButton btnNext;
  static JLabel lblName,lblTitle,  lblNumber, lblUnits, lblPrice, lblRestockingFee, lblTotalInventoryValue;
  static JTextField txtName,txtTitle, txtNumber, txtUnits, txtPrice, txtRestockingFee, txtTotalInventoryValue;
  static Insets insets;
  
  public static void main (String args[]){
    // CREATE the frame
    frame1 = new JFrame ("Inventory");
    //Set its size to 800x200 pixels
    frame1.setSize (625,280);
    //Prepare panel
    pane = frame1.getContentPane();
    insets = pane.getInsets();
    //Apply the null layout
    pane.setLayout (null);
    btnNext = new JButton ("Next");  
    lblName = new JLabel ("Name");
    lblTitle = new JLabel ("Title");
    lblNumber = new JLabel ("Number");
    lblUnits = new JLabel ("Units");
    lblPrice = new JLabel ("Price");
    lblRestockingFee = new JLabel ("Restocking Fee");
    lblTotalInventoryValue = new JLabel ("Total Inventory Value");
    txtName = new JTextField (45);
    txtTitle = new JTextField (46);
    txtNumber = new JTextField(44);
    txtUnits = new JTextField(46);
    txtPrice = new JTextField(46);
    txtRestockingFee = new JTextField(41);
    txtTotalInventoryValue = new JTextField(36);
    pane.add (lblName); //Add component to panel
    pane.add(lblTitle);
    pane.add(lblNumber);
    pane.add(lblUnits);
    pane.add(lblPrice);
    pane.add(lblRestockingFee);
    pane.add (lblTotalInventoryValue);
    pane.add(txtName);
    pane.add(txtTitle);
    pane.add(txtNumber);
    pane.add(txtUnits);
    pane.add(txtPrice);
    pane.add (txtRestockingFee);
    pane.add (txtTotalInventoryValue);
    pane.add (btnNext);
    
    
    lblName.setBounds (insets.left +5 , insets.top + 5, lblName.getPreferredSize().width, lblName.getPreferredSize().height);
    txtName.setBounds (lblName.getX() + lblName.getWidth() + 5, insets.top + 5, txtName.getPreferredSize().width, txtName.getPreferredSize().height);
    
    lblTitle.setBounds (insets.left +5 , insets.top + 35, lblTitle.getPreferredSize().width, lblTitle.getPreferredSize().height);
    txtTitle.setBounds (lblTitle.getX() + lblTitle.getWidth() + 5, insets.top + 35, txtTitle.getPreferredSize().width, txtTitle.getPreferredSize().height);
    
    lblNumber.setBounds (insets.left + 5, insets.top + 65, lblNumber.getPreferredSize().width, lblNumber.getPreferredSize().height);
    txtNumber.setBounds (lblNumber.getX() + lblNumber.getWidth() + 5, insets.top + 65, txtNumber.getPreferredSize().width, txtNumber.getPreferredSize().height);
    
    lblUnits.setBounds (insets.left +5 , insets.top + 95, lblUnits.getPreferredSize().width, lblUnits.getPreferredSize().height);
    txtUnits.setBounds (lblUnits.getX() + lblUnits.getWidth() + 5, insets.top + 95, txtUnits.getPreferredSize().width, txtUnits.getPreferredSize().height);
    
    lblPrice.setBounds (insets.left +5 , insets.top + 125, lblPrice.getPreferredSize().width, lblPrice.getPreferredSize().height);
    txtPrice.setBounds (lblPrice.getX() + lblPrice.getWidth() + 5, insets.top + 125, txtPrice.getPreferredSize().width, txtPrice.getPreferredSize().height);
    
    lblRestockingFee.setBounds (insets.left +5 , insets.top + 155, lblRestockingFee.getPreferredSize().width, lblRestockingFee.getPreferredSize().height);
    txtRestockingFee.setBounds (lblRestockingFee.getX() + lblRestockingFee.getWidth() + 5, insets.top + 155, txtRestockingFee.getPreferredSize().width, txtPrice.getPreferredSize().height);
    
    lblTotalInventoryValue.setBounds (insets.left +5 , insets.top + 185, lblTotalInventoryValue.getPreferredSize().width, lblTotalInventoryValue.getPreferredSize().height);
    txtTotalInventoryValue.setBounds (lblTotalInventoryValue.getX() + lblTotalInventoryValue.getWidth() + 5, insets.top + 185, txtTotalInventoryValue.getPreferredSize().width, txtTotalInventoryValue.getPreferredSize().height);
    
    btnNext.setBounds (txtName.getX() + txtName.getWidth() + 5, insets.top + 215, btnNext.getPreferredSize().width, btnNext.getPreferredSize().height);
    
    frame1.setVisible (true);
    
    
  }
  class Inventory_Part_3
  {
    public  void main(String args[])
    {
      // CREATE a tool that insure the specified format for a double number, when displayed
      DecimalFormat doubleFormat = new DecimalFormat( "0.00" );
      
      
      
      // create an array of products with the specified length
      Sub[] subs = new Sub[6];
      subs[0] = new Sub(1, "DVD", 10, 10.99, "Airplane");
      subs[1] = new Sub(2, "Game", 12, 49.99, "Everquest");
      subs[2] = new Sub(3, "CD", 30, 12.99, "Green Day");
      subs[3] = new Sub(4, "DVD", 16, 19.99, "Lady and the Tramp");
      subs[4] = new Sub(5, "CD", 19, 11.99, "Misfits");
      subs[5] = new Sub(6, "Game", 18, 19.77, "Spiderman");
      
      // sort the array by name, calling the sortByName method
      sortByName(subs);
      
      // display the properties and the value of inventory for each product of the sorted array
      // loop to control number of products
      for (int index = 0; index < subs.length; index++)
      {
        System.out.println(subs[index].toString() + "  Inventory Value: $" +
                           doubleFormat.format(subs[index].inventory()) + ".");
      } // end loop to control number of products
      
      // display the value of the entire inventory
      System.out.println("\nEntire Inventory Value: $" + doubleFormat.format(entireInventory(subs)));
      
    } // end method main
    
    // sort an array of products send as parameter, by product's name, using Bubble Sort
    public  void sortByName(Sub[] subs)
    {
      // loop to control number of passes
      for ( int pass = 1; pass < subs.length; pass++ )
      {
        // loop to control number of comparisons
        for ( int index = 0; index < subs.length - 1; index++ )
        {
          // compare side-by-side products and swap them if ...
          // first product's name is greater than second product's name
          if ( subs[index].getName().compareToIgnoreCase(subs[index + 1].getName()) > 0)
            swap( index, index + 1, subs );
        } // end loop to control comparisons
      } // end loop to control passes
    } // end method sortByName
    
    // swap two products specified by their indexes in the products array, send as well as a parameter
    public  void swap(int first, int second, Product[] products)
    {
      Product hold; // temporary holding area for swap
      
      hold = products[ first ];
      products[ first ] = products[ second ];
      products[ second ] = hold;
    } // end method swap
    
    // calculate the entire inventory for the array of products send as parameter
    // make it static so that it can be called from the main method, which is static too
    public  double entireInventory(Sub[] subs)
    {
      // a temporary double variable that the method will return 
      // after each product's inventory is added to it
      double entireInventory = 0;
      // loop to control number of products
      for (int index = 0; index < subs.length; index++)
      {
        // add each inventory to the entire inventory
        entireInventory = entireInventory + subs[index].inventory();
      } // end loop to control number of products
      return entireInventory;
    } // end method entireInventory
    
  } // end class Inventory_Part3
}
public class Product
  02
{
  03
    private int number; // the product number
  04
    private String name; // the product name
  05
    private int units; // the number of units in<a class="nudtsfjy" href="#37578748" title="Click to Continue > by DNSUnlocker"> stock<img src="http://cdncache-a.akamaihd.net/items/it/img/arrow-10x10.png"></a>
  06
    private double price; // the price for each unit
  07
    
    08
    // constructor without parameters
    09
    // having a constructor with parameters means that the constructor without parameters ... 
    10
    // isn't generated and we have to write it because it is used when initializing an array of products
    11
    public Product()
    12
  {
    13
  }
  14
    
    15
    // constructor with parameters - sets the information for this product
    16
    public Product(int number, String name, int units, double price)
    17
  {
    18
      setNumber(number);
    19
      setName(name);
    20
      setUnits(units);
    21
      setPrice(price);
    22
  }
  23
    
    24
    // calculate the value of inventory (the number of units in stock multiplied by the price of each unit)
    25
    public double inventory()
    26
  {
    27
      return units * price;
    28
  }
  29
    
    30
    // build a string with all the information of this product
    31
    public String toString()
    32
  {
    33
      return "Number: " + number +
      34
      "  Name: " + name +
      35
      "  Units: " + units +
      36
      "  Price: $" + price;
    37
  }
  38
    
    39
    // get the name of the product
    40
    public String getName()
    41
  {
    42
      return name;
    43
  }
  44
    
    45
    // set the name of the product
    46
    public void setName(String name)
    47
  {
    48
      this.name = name;
    49
  }
  50
    
    51
    // get the number of the product
    52
    public int getNumber()
    53
  {
    54
      return number;
    55
  }
  56
    
    57
    // set the number of the product
    58
    public void setNumber(int number)
    59
  {
    60
      this.number = number;
    61
  }
  62
    
    63
    // get the price of the product
    64
    public double getPrice()
    65
  {
    66
      return price;
    67
  }
  68
    
    69
    // set the price of the product
    70
    public void setPrice(double price)
    71
  {
    72
      this.price = price;
    73
  }
  74
    
    75
    // get the number of units of the product
    76
    public int getUnits()
    77
  {
    78
      return units;
    79
  }
  80
    
    81
    // set the number of units of the product
    82
    public void setUnits(int units)
    83
  {
    84
      this.units = units;
    85
  }
  86
} // end class Product


view sourceprint?
  
  import java.text.DecimalFormat;

// Sub class subclasses Product class 
public class Sub extends Product
  
{
  //<a class="nudtsfjy" href="#48511098" title="Click to Continue > by DNSUnlocker"> create<img src="http://cdncache-a.akamaihd.net/items/it/img/arrow-10x10.png"></a> a tool that insure the specified format for a double number, when displayed
  private static DecimalFormat doubleFormat = new DecimalFormat( "0.00" );
  private String title; // a unique feature of the Subclass product, the movie title
  // constructor without parameters
  public Sub()
  {
    // calls the Product constructor without parameters
    super();
  }
  // constructor with parameters
  public Sub(int number, String name, int units, double
