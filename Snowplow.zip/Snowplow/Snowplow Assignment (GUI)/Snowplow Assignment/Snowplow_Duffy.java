import java.util.Scanner;//import scanner
import java.util.Random;//import random

class Snowplow_Duffy{
  public static void main (String args[]){
    Random rand = new Random();//create a random number generator called random
    
    int[][] arr;//create the 2d array that stores all the numbers
    boolean firstOneFound=false;//a boolean that checks if the first one is found or not
    int r1=0,c1=0;//variables that stores the position of the first one in the grid
    
    arr = new int[8][8];//set the number of rows and columns for the 2d array (8,8)
    
    for (int row = 0; row < arr.length; row++) {
      for (int col = 0; col < arr[row].length; col++) {
        System.out.print((arr[row][col] = rand.nextInt(2) + 1) + " ");   //test on console     
        
        if (!firstOneFound && row == 0 && arr[row][col] == 1){ //if 1 was found on the first row
          r1 = row; //set row where it was first found
          c1 = col; //set column where it was first found
          firstOneFound = true; //set firstFound to true (it was found on the first row)
        }
      }
      System.out.println();
    }
    
    //find the first 1 value in the first row
    if (firstOneFound){
      System.out.println("position of the first 1 value = " + "(" + r1 + "," + c1 + ").");
    } else {
      //when there is no 1 found in the first row
      System.out.println("the plow is not used"); 
    }
    
    //clear
    clear(arr,r1,c1);    
  }
  
  //**************clear method****************
  public static void clear (int[][] grid, int r, int c) { //this plows or clears the unblocked snow (1's)
    grid[r][c] = 0; //set the first position to zero
    
    for (int row = 0; row < grid.length; row++) {
      for (int col = 0; col < grid[row].length; col++) {
        if (r >= 0 && r <= 7 || c >= 0 && c <= 7) { //if not out of bounds
          System.out.print(grid[row][col] + " "); //test on console
          //gridLabel[row][col].setText(Integer.toString(grid[row][col])+ " "); //convert numbers to strings
          
          if(grid[row][col] == 0){ //if the number equals to zero, make it blue colour
            //call clear method to check for 1s around it (up, down, and diagionally)
            clear (grid, r + 1, c);
            clear (grid, r + 1, c + 1);
            clear (grid, r + 1, c - 1);
            clear (grid, r - 1, c);
            clear (grid, r - 1, c - 1);
            clear (grid, r - 1, c + 1);
            clear (grid, r, c + 1);
            clear (grid, r, c - 1);
            //gridLabel[row][col].setForeground(Color.BLUE); //display grid or snow plowed in blue
          }
        }
      }
    }   
  }
}